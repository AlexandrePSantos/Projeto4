// npm package: inputmask
// github link: https://github.com/RobinHerbots/Inputmask

(function($) {
  'use strict';

  // initializing inputmask
  $(":input").inputmask();

})(jQuery);